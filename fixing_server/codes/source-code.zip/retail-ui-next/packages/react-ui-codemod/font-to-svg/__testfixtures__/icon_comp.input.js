import Icon from "retail-ui/Icon";

props => <Icon name={props.name} />;

﻿namespace SKBKontur.SeleniumTesting
{
    public interface IPageActionAttribute
    {
        void OnInit(PageBase pageInstace);
    }
}
module.exports = {
  testResultsProcessor: "jest-teamcity-reporter"
};

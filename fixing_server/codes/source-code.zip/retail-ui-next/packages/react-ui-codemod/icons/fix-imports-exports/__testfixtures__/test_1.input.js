import Icon from "../../foo/bar/../Icon/Icon.tsx";

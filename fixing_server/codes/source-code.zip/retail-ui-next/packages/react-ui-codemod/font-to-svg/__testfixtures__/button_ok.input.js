import Button from "retail-ui/Button";

() => <Button icon="Ok" />;

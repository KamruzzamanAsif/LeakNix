﻿namespace SKBKontur.SeleniumTesting.Controls
{
    public class InternalCompoundControl : ControlBase
    {
        protected InternalCompoundControl(ISearchContainer container, ISelector selector)
            : base(container, selector)
        {
        }
    }
}
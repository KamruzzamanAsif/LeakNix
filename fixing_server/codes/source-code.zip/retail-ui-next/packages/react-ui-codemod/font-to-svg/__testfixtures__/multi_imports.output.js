import React from "react";
import { Link } from "retail-ui/Link";

import OkIcon from "@skbkontur/react-icons/Ok";

() => <Link icon={<OkIcon />} />;

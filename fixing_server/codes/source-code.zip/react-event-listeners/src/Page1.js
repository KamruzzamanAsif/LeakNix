import React, { useEffect } from 'react';

function Page1() {
  useEffect(() => {
    const handleResize = () => {
      console.log('Window resized to:', window.innerWidth, window.innerHeight);
    };

    // Memory leak: Adding a window resize listener but never removing it
    window.addEventListener('resize', handleResize);

    // Memory leak: Timeout not cleared
    const timeoutID = setTimeout(() => {
      console.log('This timeout will not be cleared');
    }, 5000);

    return () => {
      // Intentionally not cleaning up the resize event listener and timeout (memory leak)
      // Normally you should do:
      // window.removeEventListener('resize', handleResize);
      // clearTimeout(timeoutID);
    };
  }, []);

  return (
    <div>
      <h1>Page 1 - Resize Event and Timer Memory Leaks</h1>
      <p>Resize the window to trigger the memory-leaking resize event listener.</p>
      <p>A timeout is also running in the background that won’t be cleared.</p>
    </div>
  );
}

export default Page1;

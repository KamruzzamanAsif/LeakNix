var { versions } = require('./versions');

console.log(versions);

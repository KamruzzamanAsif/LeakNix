import { MenuItem } from "retail-ui/MenuItem";
import Icon from "retail-ui/Icon";

() => <MenuItem icon={<Icon name="Ok" />} />;

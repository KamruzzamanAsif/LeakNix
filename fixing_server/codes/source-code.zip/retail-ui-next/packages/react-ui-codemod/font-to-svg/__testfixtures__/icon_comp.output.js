import Icon from "@skbkontur/react-icons";

props => <Icon name={props.name} />;

import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div>
      <h1>Welcome to the Memory Leak Demo</h1>
      <p>
        <Link to="/page1">Go to Page 1 ((Resize & Timer))</Link>
      </p>
      <p>
        <Link to="/page2">Go to Page 2 (Notification Example)</Link>
      </p>
      <p>
        <Link to="/page3">Go to Page 3 (Event Driven Arcitechture)</Link>
      </p>
    </div>
  );
}

export default Home;

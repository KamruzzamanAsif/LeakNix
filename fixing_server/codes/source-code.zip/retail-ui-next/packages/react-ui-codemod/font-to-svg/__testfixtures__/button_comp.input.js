import Button from "retail-ui/Button";

props => <Button icon={props.icon} />;

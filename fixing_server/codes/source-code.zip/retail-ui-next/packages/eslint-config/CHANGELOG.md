# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.0.2](https://github.com/skbkontur/retail-ui/compare/@skbkontur/eslint-config@1.0.1...@skbkontur/eslint-config@1.0.2) (2021-05-12)

**Note:** Version bump only for package @skbkontur/eslint-config





## 1.0.1 (2020-03-24)

**Note:** Version bump only for package @skbkontur/eslint-config

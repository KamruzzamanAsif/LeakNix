import OkIcon from "@skbkontur/react-icons/Ok";

() => <OkIcon />;

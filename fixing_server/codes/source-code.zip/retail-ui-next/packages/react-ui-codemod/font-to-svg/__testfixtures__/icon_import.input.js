import { Icon, Button, Input } from "retail-ui";

() => <Icon name="Ok" />;

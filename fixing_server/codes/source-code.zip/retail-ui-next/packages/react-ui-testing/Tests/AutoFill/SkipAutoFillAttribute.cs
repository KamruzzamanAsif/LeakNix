using System;

namespace SKBKontur.SeleniumTesting.Tests.AutoFill
{
    public class SkipAutoFillAttribute : Attribute
    {
    }
}
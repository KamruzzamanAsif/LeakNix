﻿using System;

namespace SKBKontur.SeleniumTesting
{
    public class LoadingCompleteAttribute : Attribute
    {
    }
}
import React, { useEffect, useState } from 'react';


class MyData {
  constructor() {
    this.name = 'my-data';
    this.state = "truetype";
    this.stateChange = "changed";
  }
}
// Global storage for leaking memory
const globalLeakedArray = [];


const Page4 = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    // Create a new MyData instance and push to globalLeakedArray
    const myDataInstance = new MyData();
    globalLeakedArray.push(myDataInstance);

    // Simulate updating React state to cause re-renders
    setInterval(() => {
      setData((prevData) => [...prevData, `Item ${prevData.length + 1}`]);
    }, 500); // Update every 500ms

    // Intentionally leave no cleanup
    return () => {
      // Uncommenting this would stop the memory leak:
      // clearInterval(intervalID);
    };
  }, [data]);

  return (
    <div>
      <h1>Page 4 - Heavy Memory Leak</h1>
      <ul>
        {data.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
      <p>Items in globalLeakedArray: {globalLeakedArray.length}</p>
    </div>
  );
};

export default Page4;

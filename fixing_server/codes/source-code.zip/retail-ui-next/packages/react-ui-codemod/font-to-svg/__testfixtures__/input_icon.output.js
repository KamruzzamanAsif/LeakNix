import { Input } from "retail-ui/Input";
import OkIcon from "@skbkontur/react-icons/Ok";
import CloudIcon from "@skbkontur/react-icons/Cloud";

() => <Input leftIcon={<OkIcon />} rightIcon={<CloudIcon />} />;

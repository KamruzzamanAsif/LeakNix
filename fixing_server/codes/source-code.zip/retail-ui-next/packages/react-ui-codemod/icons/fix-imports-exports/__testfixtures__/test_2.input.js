export * from "retail-ui/components/Icon";
export {default as Icon} from "retail-ui/components/Icon";

namespace SKBKontur.SeleniumTesting.Tests.PageActionAttributesTests.PageActionAttributes
{
    [TestPageAction("IPageInterface2")]
    public interface IPageInterface2
    {
    }
}
import { MenuItem } from "retail-ui/MenuItem";

() => <MenuItem icon="Ok" />;

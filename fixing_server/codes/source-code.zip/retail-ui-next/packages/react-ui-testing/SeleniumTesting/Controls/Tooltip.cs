﻿namespace SKBKontur.SeleniumTesting.Controls
{
    public class Tooltip : ControlBase
    {
        public Tooltip(ISearchContainer container, ISelector selector)
            : base(container, selector)
        {
        }
    }
}
import React from 'react'

const LineDivider = () => {
  return (
    <div className='w-full border-t border-borderLight'></div>
  )
}

export default LineDivider
export enum FocusMode {
  'Errors',
  'ErrorsAndWarnings',
  'None',
}

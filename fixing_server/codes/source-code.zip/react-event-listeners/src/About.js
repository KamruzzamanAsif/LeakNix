import React from 'react';
import { useEffect, useState } from 'react';

// Global array that will cause a memory leak
let leakingArray = [];

const generateHeavyObject = () => {
    const heavyObject = {};
    for (let i = 0; i < 10000; i++) {
        heavyObject[`key_${i}`] = `value_${i}_${Math.random()}`;
    }
    return heavyObject;
};

const formatSizeUnits = (bytes) => {
    if (bytes >= 1048576) {
        return (bytes / 1048576).toFixed(2) + ' MB';
    } else if (bytes >= 1024) {
        return (bytes / 1024).toFixed(2) + ' KB';
    } else {
        return bytes + ' bytes';
    }
};

const roughSizeOfObject = (object) => {
    const objectList = [];
    const stack = [object];
    let bytes = 0;

    while (stack.length) {
        const value = stack.pop();

        if (typeof value === 'boolean') {
            bytes += 4;
        } else if (typeof value === 'string') {
            bytes += value.length * 2;
        } else if (typeof value === 'number') {
            bytes += 8;
        } else if (typeof value === 'object' && objectList.indexOf(value) === -1) {
            objectList.push(value);
            for (const i in value) {
                stack.push(value[i]);
            }
        }
    }
    return bytes;
};

const causeMemoryLeak = () => {
  let n = 10;
    while (n>0) {
        // Generate a heavy object and push it to the leakingArray
        leakingArray.push(generateHeavyObject());

        // Log the size of the array and the approximate memory usage
        const totalSizeBytes = leakingArray.reduce(
            (acc, obj) => acc + roughSizeOfObject(obj),
            0
        );
        console.log('Current leakingArray size:', leakingArray.length);
        console.log('Approximate memory usage of leakingArray:', formatSizeUnits(totalSizeBytes));

        // Pause briefly to slow down the loop (optional)
        const pause = performance.now() + 100;
        while (performance.now() < pause);

        n = n-1;
    }
};

const About = () => {
    const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
    const [scrollPosition, setScrollPosition] = useState(window.scrollY);

    useEffect(() => {
        const handleMouseMove = (event) => {
            setMousePosition({ x: event.clientX, y: event.clientY });
        };

        const handleScroll = () => {
            setScrollPosition(window.scrollY);
        };

        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('scroll', handleScroll);

        // Trigger the infinite loop memory leak
        causeMemoryLeak();

        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    return (
        <div style={{ textAlign: 'center', marginTop: '50px' }}>
            <h1>Second Page</h1>
            <p>This is the second page.</p>
            <p>Mouse position: {mousePosition.x}, {mousePosition.y}</p>
            <p>Scroll position: {scrollPosition}</p>
        </div>
    );
};

export default About;

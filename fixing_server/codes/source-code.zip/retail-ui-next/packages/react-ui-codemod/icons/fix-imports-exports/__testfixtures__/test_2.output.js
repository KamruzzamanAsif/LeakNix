export * from "react-ui-icons";
export {default as Icon} from "react-ui-icons";

import { buildConfig } from './rollup.base.config.mjs';

export default buildConfig('react-ui-dist', '@skbkontur/react-ui');

import Icon from "retail-ui/Icon";

() => (
  <>
    <Icon name="Ok" />
    <Icon name="Cloud" size="15" />
    <Icon name="Add" color="red" />
  </>
);

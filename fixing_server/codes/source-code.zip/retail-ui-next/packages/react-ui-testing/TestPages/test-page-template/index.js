import TestPageApplication from '../src/index';

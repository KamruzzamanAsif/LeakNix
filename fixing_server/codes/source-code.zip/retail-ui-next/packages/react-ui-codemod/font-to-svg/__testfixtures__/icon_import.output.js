import { Button, Input } from "retail-ui";

import OkIcon from "@skbkontur/react-icons/Ok";

() => <OkIcon />;

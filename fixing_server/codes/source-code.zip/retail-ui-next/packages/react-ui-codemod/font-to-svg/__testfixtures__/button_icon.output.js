import Button from "retail-ui/Button";
import OkIcon from "@skbkontur/react-icons/Ok";

() => <Button icon={<OkIcon />} />;

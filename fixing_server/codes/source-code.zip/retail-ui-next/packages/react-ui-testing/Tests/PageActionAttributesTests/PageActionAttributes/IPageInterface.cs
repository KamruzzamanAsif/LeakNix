﻿namespace SKBKontur.SeleniumTesting.Tests.PageActionAttributesTests.PageActionAttributes
{
    [TestPageAction("IPageInterface")]
    public interface IPageInterface
    {
    }
}
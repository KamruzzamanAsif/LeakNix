module.exports = {
  projects: ['<rootDir>/packages/*'],
  roots: ['<rootDir>/packages/*'],
};

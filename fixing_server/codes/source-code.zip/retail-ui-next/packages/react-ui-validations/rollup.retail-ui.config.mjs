import { buildConfig } from './rollup.base.config.mjs';

export default buildConfig('retail-ui-dist', 'retail-ui');

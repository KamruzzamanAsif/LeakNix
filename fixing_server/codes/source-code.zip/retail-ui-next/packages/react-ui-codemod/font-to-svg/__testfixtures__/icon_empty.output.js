import Icon from "@skbkontur/react-icons";

() => <Icon />;

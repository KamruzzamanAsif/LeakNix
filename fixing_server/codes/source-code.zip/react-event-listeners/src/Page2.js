import React, { useEffect, useState } from 'react';

const Page2 = () => {
  const [notifications, setNotifications] = useState(0);

  useEffect(() => {
    // Simulate a subscription using setInterval
    const subscriptionID = setInterval(() => {
      console.log('Fetching new notifications...');
      setNotifications((prev) => prev + 1); // Simulate getting new notifications
    }, 2000); // Polling every 2 seconds

    // Memory leak: The interval is never cleared when the component unmounts
    return () => {
      // Intentionally leaving the cleanup blank to simulate the memory leak
      // Normally, you'd do: clearInterval(subscriptionID);
    };
  }, []);

  return (
    <div>
      <h1>Page 2 - Notifications Counter</h1>
      <p>You have {notifications} new notifications.</p>
    </div>
  );
};

export default Page2;

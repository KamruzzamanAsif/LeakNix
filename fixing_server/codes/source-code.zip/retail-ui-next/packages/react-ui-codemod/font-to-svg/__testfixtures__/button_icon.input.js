import Button from "retail-ui/Button";
import Icon from "retail-ui/Icon";

() => <Button icon={<Icon name="Ok" />} />;

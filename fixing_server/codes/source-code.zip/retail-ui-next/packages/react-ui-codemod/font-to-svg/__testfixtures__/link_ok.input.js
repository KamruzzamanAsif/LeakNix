import { Link } from "retail-ui/Link";

() => <Link icon="Ok" />;

import { Link } from "retail-ui/Link";
import Icon from "retail-ui/Icon";

() => <Link icon={<Icon name="Ok" />} />;

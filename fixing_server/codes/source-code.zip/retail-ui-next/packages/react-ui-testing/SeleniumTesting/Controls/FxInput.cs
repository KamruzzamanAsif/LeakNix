﻿namespace SKBKontur.SeleniumTesting.Controls
{
    public class FxInput : Input
    {
        public FxInput(ISearchContainer container, ISelector selector)
            : base(container, selector)
        {
        }
    }
}
namespace SKBKontur.SeleniumTesting.Tests.PageActionAttributesTests.PageActionAttributes
{
    [TestPageAction("IPageInterface1")]
    public interface IPageInterface1
    {
    }
}
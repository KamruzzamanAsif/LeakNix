import { Input } from "retail-ui/Input";
import Icon from "retail-ui/Icon";

() => <Input leftIcon={<Icon name="Ok" />} rightIcon={<Icon name="Cloud" />} />;

import Icon from "retail-ui/Icon";

() => <Icon name="Ok" />;

import OkIcon from "@skbkontur/react-icons/Ok";
import CloudIcon from "@skbkontur/react-icons/Cloud";
import AddIcon from "@skbkontur/react-icons/Add";

() => (
  <>
    <OkIcon />
    <CloudIcon size="15" />
    <AddIcon color="red" />
  </>
);

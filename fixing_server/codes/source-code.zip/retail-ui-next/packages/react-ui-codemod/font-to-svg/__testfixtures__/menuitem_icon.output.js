import { MenuItem } from "retail-ui/MenuItem";
import OkIcon from "@skbkontur/react-icons/Ok";

() => <MenuItem icon={<OkIcon />} />;

import React from "react";
import { Link } from "retail-ui/Link";

() => <Link icon="Ok" />;

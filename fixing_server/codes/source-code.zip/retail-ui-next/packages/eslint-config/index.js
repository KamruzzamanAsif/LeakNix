module.exports = require('./eslint.config');
